// Integration test for the staged browser UI: real data, copied script and legacy links.
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const dir=path.resolve(__dirname,'../../outputs/uc-ifade-v2');
const core=require('./widget-core.js');
const data=JSON.parse(fs.readFileSync(dir+'/collection-v2.json','utf8'));
const code=fs.readFileSync(dir+'/widget-site-v2.js','utf8');
const script=fs.readFileSync(dir+'/Ifade-v2.js','utf8');
function node(tag='div') {return {tag,children:[],events:{},value:'',textContent:'',open:false,
 append(...children){this.children.push(...children)},replaceChildren(...children){this.children=children},
 addEventListener(t,f){this.events[t]=f},showModal(){this.open=true},close(){this.open=false;this.events.close?.()},focus(){},select(){}}}
const nodes={};for(const id of ['detail-body','detail','widget-count','count','slot-time','current-six','now','search','search-status','results','more','prev','next','script-text','copy-status','copy-script','manual-copy'])nodes['#'+id]=node();
nodes['#detail .close']=node();
let copied='',url='';const requests=[];
const context={document:{querySelector:s=>{assert(nodes[s],s);return nodes[s]},createElement:node,addEventListener(){}},
 navigator:{clipboard:{writeText:async s=>{copied=s}}},history:{replaceState:(a,b,u)=>url=u},
 location:{pathname:'/uc-ifade/',hash:'',search:'?entry='+Object.keys(data.aliases)[0]},
 fetch:async u=>{requests.push(u);assert(/^(Ifade-v2.js|collection-v2.json)\?/.test(u));return {ok:true,text:async()=>script,json:async()=>data}},
 IfadeCore:core,Intl,Date,URLSearchParams,encodeURIComponent,clearTimeout(){},setTimeout(){}};
vm.runInNewContext(code,context);
(async()=>{
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(nodes['#count'].textContent,'5.750');
 assert.equal(nodes['#current-six'].children.length,6);
 for(const card of nodes['#current-six'].children){assert.equal(card.children.length,3);assert.equal(card.children[1].children.length,3);assert.equal(card.children[2].children.length,3)}
 assert(nodes['#detail'].open,'Legacy alias opens its canonical entry');
 assert.equal(nodes['#detail-body'].children[1].textContent,core.findEntry(data,Object.keys(data.aliases)[0]).expression);
 const before=nodes['#current-six'].children.map(c=>c.href).join();nodes['#next'].onclick();assert.notEqual(nodes['#current-six'].children.map(c=>c.href).join(),before);
 nodes['#search'].value='bugüne kadar';nodes['#search'].events.input();assert(nodes['#results'].children.length>0);
 for(const query of ['INFAMOUS','İNFAMOUS','infamous']) {
   nodes['#search'].value=query;nodes['#search'].events.input();
   assert(nodes['#results'].children.some(c=>c.children[1].textContent==='infamous'),'English/Turkish case matching: '+query);
 }
 nodes['#search'].value='BUGUNE KADAR';nodes['#search'].events.input();assert(nodes['#results'].children.length>0,'Turkish without accents');
 nodes['#search'].value='no-match-123xyz';nodes['#search'].events.input();assert.equal(nodes['#results'].children.length,0);
 await nodes['#copy-script'].onclick();assert.equal(copied,script);assert(copied.includes('widget-data-v2.json'));
 console.log('PASS: full v2 data; 6 cards with 12 examples; alias detail; next group; Turkish search; empty results; installed script matches release.');
})().catch(e=>{console.error(e);process.exitCode=1});
