const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const core=require('./widget-core.js');
const fixture=JSON.parse(fs.readFileSync(__dirname+'/widget-data-preview.json','utf8'));
core.validate(fixture);
const fake={schema:2,version:'test',periodHours:2,aliases:{old:'e0'},entries:Array.from({length:5750},(_,i)=>({id:'e'+i,expression:'word '+i,examples:[
  {meaning:'birinci anlam',example:'First example '+i+'.',translation:'Birinci çeviri '+i+'.',relation:'primary'},
  {meaning:'ikinci anlam',example:'Second example '+i+'.',translation:'İkinci çeviri '+i+'.',relation:'different-sense'}]}))};
core.validate(fake);
const seen=[];for(let slot=0;slot<959;slot++)seen.push(...core.selection(fake,core.EPOCH+slot*core.PERIOD).entries.map(e=>e.id));
assert.equal(new Set(seen.slice(0,5750)).size,5750);assert.equal(seen[5750],'e0');
assert.equal(core.selection(fake,core.EPOCH+core.PERIOD-1).start,0);
assert.equal(core.selection(fake,core.EPOCH+core.PERIOD).start,6);
assert.equal(core.selection(fake,Date.parse('2026-10-08T00:00:00+03:00')).start,72);
assert.equal(core.findEntry(fake,'old').id,'e0');assert.equal(core.findEntry(fake,'missing'),undefined);
assert.throws(()=>core.selection(fake,NaN));
function changed(fn){const x=structuredClone(fake);fn(x);return x;}
assert.throws(()=>core.validate(changed(x=>x.schema=1)));
assert.throws(()=>core.validate(changed(x=>x.entries[0].examples.pop())));
assert.throws(()=>core.validate(changed(x=>x.entries[0].examples[1].example=x.entries[0].examples[0].example)));
assert.throws(()=>core.validate(changed(x=>x.entries[0].examples[1].translation=' ')));
assert.throws(()=>core.validate(changed(x=>x.entries[0].examples[1].relation='unverified')));
assert.throws(()=>core.validate(changed(x=>x.aliases.old='missing')));
assert.throws(()=>core.validate(changed(x=>x.entries.push(x.entries[0]))));
const code=fs.readFileSync(__dirname+'/widget-core.js','utf8')+'\n'+fs.readFileSync(__dirname+'/widget-runtime.js','utf8');
function element(){return {children:[],addStack(){const e=element();this.children.push(e);return e},addText(value){const e={value};this.children.push(e);return e},addSpacer(){},layoutVertically(){},layoutHorizontally(){},setPadding(){},async presentLarge(){}}}
async function run({cache=null,network=true,response=fake,family='large',parameter=null}={}) {
  let saved=typeof cache==='string'?cache:cache?JSON.stringify(cache):null,calls=0,shown,url;
  const ctx={module:{exports:{}},config:{widgetFamily:family,runsInWidget:true},args:{widgetParameter:parameter},
    FileManager:{local:()=>({documentsDirectory:()=>'/data',joinPath:(a,b)=>a+'/'+b,readString:()=>saved,writeString:(p,s)=>saved=s})},
    Request:class{constructor(u){url=u}async loadJSON(){calls++;if(!network)throw Error('offline');return response}},
    ListWidget:class{constructor(){Object.assign(this,element())}},Font:{semiboldSystemFont:n=>n,systemFont:n=>n},
    Color:class{},Size:class{},Script:{setWidget:w=>shown=w,complete(){}},Date,Set,JSON,Error,parseInt,encodeURIComponent};
  await vm.runInNewContext('(async()=>{'+code+'})()',ctx);
  const strings=[];function walk(e){if(e.value)strings.push(e.value);for(const c of e.children||[])walk(c)}walk(shown);
  return {strings,calls,saved,shown,url};
}
(async()=>{
  let r=await run();assert.equal(r.calls,1);assert(r.url.includes('widget-data-v2.json'));
  assert.equal(r.strings.filter(x=>x.startsWith('word ')).length,6);
  for(const prefix of ['First example','Second example','Birinci çeviri','İkinci çeviri'])assert.equal(r.strings.filter(x=>x.startsWith(prefix)).length,6);
  assert.equal(r.shown.refreshAfterDate.getTime(),core.selection(fake,Date.now()).next);
  r=await run({cache:{savedAt:Date.now(),data:fake},network:false});assert.equal(r.calls,0);
  r=await run({cache:{savedAt:0,data:fake},network:false});assert(r.strings.some(x=>x.includes('Çevrimdışı')));
  r=await run({cache:{savedAt:0,data:fake},response:{schema:1}});assert(r.strings.some(x=>x.includes('Çevrimdışı')));assert.equal(JSON.parse(r.saved).savedAt,0);
  r=await run({cache:'broken'});assert.equal(r.calls,1);
  r=await run({network:false});assert(r.strings.some(x=>x.includes('İlk yükleme')));
  r=await run({family:'medium'});assert.equal(r.strings.filter(x=>x.startsWith('word ')).length,2);
  r=await run({family:'small'});assert.equal(r.strings.filter(x=>x.startsWith('word ')).length,1);
  r=await run({family:'accessoryRectangular',parameter:'5'});assert.equal(r.strings.length,2);assert(r.shown.url.includes('?entry='));
  console.log('PASS: 5750 traversal; 2-hour and midnight boundaries; aliases; two distinct examples; translations; cache isolation; corrupt cache; invalid response fallback; first-load error; widget family counts.');
  console.log('Native iPhone layout and OS refresh scheduling require device verification.');
})().catch(e=>{console.error(e);process.exitCode=1});
