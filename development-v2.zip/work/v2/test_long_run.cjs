// Simulated clock / Scriptable API checks; not an iOS scheduler test.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const core=require('./widget-core.js');
const data=JSON.parse(fs.readFileSync(__dirname+'/../../outputs/uc-ifade-v2/widget-data-v2.json','utf8'));
core.validate(data);
const code=fs.readFileSync(__dirname+'/widget-core.js','utf8')+'\n'+fs.readFileSync(__dirname+'/widget-runtime.js','utf8');
let cache=null,totalCalls=0,failures=0,writes=0,now=core.EPOCH;
const seen=new Set(),sequence=[];
function element(){return {children:[],addStack(){const e=element();this.children.push(e);return e},addText(value){const e={value};this.children.push(e);return e},addSpacer(){},layoutVertically(){},layoutHorizontally(){},setPadding(){}};}
async function run(time,online=true,version=data.version){
 now=time;let shown,calls=0;
 class Clock extends Date{constructor(...args){super(...(args.length?args:[now]));}static now(){return now;}}
 const ctx={module:{exports:{}},config:{widgetFamily:'large',runsInWidget:true},args:{},Date:Clock,
  FileManager:{local:()=>({documentsDirectory:()=>'/data',joinPath:(a,b)=>a+'/'+b,readString:()=>cache,writeString:(p,s)=>{cache=s;writes++;}})},
  Request:class{async loadJSON(){calls++;totalCalls++;if(!online){failures++;throw Error('offline');}return {...data,version};}},
  ListWidget:class{constructor(){Object.assign(this,element());}},Color:class{},Size:class{},Font:{systemFont:n=>n,semiboldSystemFont:n=>n},Script:{setWidget:w=>shown=w,complete(){}}};
 await vm.runInNewContext('(async()=>{'+code+'})()',ctx);
 const strings=[];function walk(e){if(e.value)strings.push(e.value);for(const c of e.children||[])walk(c);}walk(shown);
 const chosen=core.selection(data,now);
 for(const e of chosen.entries){assert(strings.includes(e.expression));for(const x of e.examples){assert(strings.includes(x.example));assert(strings.includes(x.translation));}}
 assert.equal(shown.refreshAfterDate.getTime(),chosen.next);assert(chosen.next>now);
 return {chosen,calls,strings};
}
(async()=>{
 // One hundred days cover every entry and wraparound. Days 4–6 are offline.
 for(let slot=0;slot<1200;slot++){
  const day=Math.floor(slot/12),online=day<4||day>=7;
  const r=await run(core.EPOCH+slot*core.PERIOD,online,day<7?data.version:data.version+'-test-update');
  for(const e of r.chosen.entries){seen.add(e.id);sequence.push(e.id);}
  if(day>=4&&day<7)assert(r.strings.some(s=>s.includes('Çevrimdışı')));
  if(slot===84)assert.equal(JSON.parse(cache).data.version,data.version+'-test-update');
 }
 assert.equal(seen.size,5750);assert.equal(new Set(sequence.slice(0,5750)).size,5750);
 assert.equal(sequence[5750],sequence[0]);
 assert.equal(writes,97);assert.equal(failures,36);assert.equal(totalCalls,133);
 // A late OS invocation must show the current slot, not replay missed slots.
 const delayed=await run(core.EPOCH+150*86400000+37*60000);
 assert.equal(delayed.chosen.start,core.selection(data,now).start);
 const report={passed:true,entries:data.entries.length,simulatedDays:100,scheduledInvocations:1200,uniqueEntriesSeen:seen.size,offlineDays:3,failedNetworkAttemptsDuringOutage:36,successfulDailyDownloads:97,cacheRecoveredAndAdoptedNewVersion:true,delayedInvocationUsesCurrentSlot:true,nativeIOSRefreshTimingVerified:false,scope:'Actual production data and runtime with simulated clock, filesystem, network and Scriptable UI APIs. Does not measure iOS refresh scheduling.'};
 fs.writeFileSync(__dirname+'/long-run-refresh-check.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
})().catch(e=>{console.error(e);process.exitCode=1;});
