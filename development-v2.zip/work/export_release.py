"""Copy rebuilt V2 outputs into the existing website without recreating its HTML."""
import json, shutil
from pathlib import Path
B=Path(__file__).resolve().parents[1]; V=B/'work/v2'; O=B/'outputs/uc-ifade-v2'
status=json.loads((V/'review-status.json').read_text(encoding='utf8'))
if not status['publishable'] or status['reviewed']!=5750:
    raise SystemExit('Run the review/build checks before exporting.')
for source,target in [('collection.json','collection-v2.json'),('widget-data-v2.json','widget-data-v2.json'),
    ('Ifade-v2.js','Ifade-v2.js'),('widget-core.js','widget-core-v2.js'),('widget-site-v2.js','widget-site-v2.js')]:
    shutil.copyfile(V/source,O/target)
print('Exported five V2 files; existing website, guides and legacy files preserved.')
