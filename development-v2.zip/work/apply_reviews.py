"""Apply explicit linguistic revisions; machine candidates cannot mark reviews."""
import hashlib,json
from pathlib import Path
P=Path(__file__).parent/'v2'
data=json.loads((P/'collection.json').read_text(encoding='utf8'))
lookup={e['id']:e for e in data['entries']}
seen=set()
for p in sorted(P.glob('reviewed-*.tsv')):
    for number,line in enumerate(p.read_text(encoding='utf8').splitlines(),1):
        if not line.strip() or line.startswith('#'):continue
        f=line.split('|')
        assert len(f)==8,(p.name,number,len(f))
        identity,m1,en1,tr1,m2,en2,tr2,relation=f
        assert identity not in seen,identity
        seen.add(identity)
        assert relation in ('same-sense','different-sense')
        assert en1.casefold()!=en2.casefold()
        e=lookup[identity]
        e['examples']=[{'meaning':m,'example':en,'translation':tr,'contentOrigin':'project-original',
            'relation':rel} for m,en,tr,rel in [(m1,en1,tr1,'primary'),(m2,en2,tr2,relation)]]
        e.update(meaning=m1 if m1==m2 else m1+'; '+m2,example=en1,translation=tr1,contentOrigin='project-original')
        e.pop('attribution',None);e.pop('alignmentScore',None)
        e['review']={'status':'reviewed','version':2,'reviewer':'AI-assisted editorial review',
            'checks':['source-headword','part-of-speech','sense-example-alignment','english-grammar','turkish-translation','distinct-examples'],
            'record':p.name+':'+str(number),'contentHash':hashlib.sha256(json.dumps(e['examples'],ensure_ascii=False,sort_keys=True).encode()).hexdigest()}
errata_path=P/'source-errata.json'
if errata_path.exists():
    for identity,erratum in json.loads(errata_path.read_text(encoding='utf8'))['entries'].items():
        assert identity in lookup,identity
        lookup[identity]['sourceErratum']=erratum
        lookup[identity]['partOfSpeech']=erratum['correctedPartOfSpeech']
(P/'collection.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf8')
print('Explicitly reviewed',len(seen),'/',len(lookup),'entries')
