"""Release only complete reviewed content; --preview writes an explicit test fixture."""
import argparse,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--preview',action='store_true');a=ap.parse_args()
data=json.loads((P/'collection.json').read_text(encoding='utf8'))
assert len(data['entries'])==5750
reviewed=[];failures=[]
for e in data['entries']:
    reasons=[]
    if e.get('review',{}).get('status')!='reviewed':reasons.append('linguistic-review-pending')
    if len(e.get('examples',[]))!=2:reasons.append('second-example-missing')
    elif e['examples'][1].get('relation') not in ('same-sense','different-sense'):reasons.append('sense-relation-unverified')
    if not reasons:
        digest=hashlib.sha256(json.dumps(e['examples'],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
        if digest!=e['review'].get('contentHash'):reasons.append('content-changed-after-review')
    if reasons:failures.append({'id':e['id'],'expression':e['expression'],'reasons':reasons})
    else:reviewed.append(e)
report={'total':len(data['entries']),'reviewed':len(reviewed),'pending':len(failures),'publishable':not failures,'failures':failures}
(P/'review-status.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k!='failures'}))
if failures and not a.preview:raise SystemExit('Release blocked: complete the record-level reviews before publishing v2.')
entries=reviewed if a.preview else data['entries']
ids={e['id'] for e in entries}
out={'schema':2,'version':data['version'],'periodHours':2,'preview':bool(a.preview),
    'aliases':{k:v for k,v in data['aliases'].items() if v in ids},'entries':[
        {'id':e['id'],'expression':e['expression'],'examples':[
            {k:s[k] for k in ['meaning','example','translation','relation']} for s in e['examples']]} for e in entries]}
name='widget-data-preview.json' if a.preview else 'widget-data-v2.json'
(P/name).write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')),encoding='utf8')
(P/'Ifade-v2.js').write_text('// İfade v2 · Two examples per entry\n'+(P/'widget-core.js').read_text(encoding='utf8')+'\n'+(P/'widget-runtime.js').read_text(encoding='utf8'),encoding='utf8')
